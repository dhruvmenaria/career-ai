import Link from "next/link";
import { ArrowLeft, Download, FileText } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import type { Metadata } from "next";

export const metadata: Metadata = { title: "Resume Session" };

export default function ResumeSessionPage({ params }: { params: { id: string } }) {
  return (
    <div className="mx-auto max-w-4xl space-y-6 animate-in-up">
      <div className="flex items-center gap-3">
        <Button variant="ghost" size="sm" asChild>
          <Link href="/resume">
            <ArrowLeft className="mr-1.5 h-4 w-4" />
            Back to Vault
          </Link>
        </Button>
      </div>
      <div className="flex items-start justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Resume Session</h1>
          <p className="text-sm text-muted-foreground">ID: {params.id}</p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" size="sm">
            <Download className="mr-1.5 h-3.5 w-3.5" /> DOCX
          </Button>
          <Button size="sm">
            <Download className="mr-1.5 h-3.5 w-3.5" /> PDF
          </Button>
        </div>
      </div>
      <Card className="border-dashed">
        <CardContent className="flex flex-col items-center gap-4 py-16 text-center">
          <FileText className="h-10 w-10 text-muted-foreground" />
          <p className="text-muted-foreground text-sm">
            This session is stored in your database. Connect Supabase + Prisma to load saved sessions.
          </p>
          <Button asChild variant="outline">
            <Link href="/resume/new">Create New Session</Link>
          </Button>
        </CardContent>
      </Card>
    </div>
  );
}
