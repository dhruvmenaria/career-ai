import Link from "next/link";
import { ArrowLeft, MessagesSquare } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import type { Metadata } from "next";

export const metadata: Metadata = { title: "Interview Session" };

export default function InterviewSessionDetailPage({ params }: { params: { id: string } }) {
  return (
    <div className="mx-auto max-w-4xl space-y-6 animate-in-up">
      <Button variant="ghost" size="sm" asChild>
        <Link href="/interview"><ArrowLeft className="mr-1.5 h-4 w-4" />All Sessions</Link>
      </Button>
      <div>
        <h1 className="text-2xl font-bold tracking-tight">Interview Session</h1>
        <p className="text-sm text-muted-foreground">ID: {params.id}</p>
      </div>
      <Card className="border-dashed">
        <CardContent className="flex flex-col items-center gap-4 py-16 text-center">
          <MessagesSquare className="h-10 w-10 text-muted-foreground" />
          <p className="text-sm text-muted-foreground">
            Connect Supabase + Prisma to load saved interview sessions from your database.
          </p>
          <Button asChild>
            <Link href="/interview/new">Start New Session</Link>
          </Button>
        </CardContent>
      </Card>
    </div>
  );
}
