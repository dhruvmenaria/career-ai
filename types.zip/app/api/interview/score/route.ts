import { NextResponse } from "next/server";
import { z } from "zod";
import { createFallbackScore, scoreInterviewAnswer } from "@/lib/ai/interview-gen";
import { getRequestUser } from "@/lib/auth";
import { hasAnthropicConfig, hasDatabaseConfig } from "@/lib/env";
import { prisma } from "@/lib/prisma";
import type { InterviewQuestion } from "@/types/interview";

export const runtime = "nodejs";

const scoreSchema = z.object({
  questionId: z.string(),
  sessionId: z.string().optional().nullable(),
  question: z.string().min(5),
  modelAnswer: z.string().min(5),
  userAnswer: z.string().min(10)
});

export async function POST(request: Request) {
  const user = await getRequestUser();
  if (!user) {
    return NextResponse.json({ message: "Authentication required." }, { status: 401 });
  }

  try {
    const input = scoreSchema.parse(await request.json());
    const result = hasAnthropicConfig()
      ? await scoreInterviewAnswer(input.question, input.modelAnswer, input.userAnswer)
      : createFallbackScore(input.userAnswer);

    let readiness = result.score;
    if (hasDatabaseConfig() && user.dbUserId && input.sessionId) {
      const session = await prisma.interviewSession.findFirst({
        where: { id: input.sessionId, userId: user.dbUserId }
      });

      if (session) {
        const questions = session.questions as InterviewQuestion[];
        const nextQuestions = questions.map((question) =>
          question.id === input.questionId
            ? { ...question, userAnswer: input.userAnswer, score: result.score }
            : question
        );
        const scored = nextQuestions.filter((question) => typeof question.score === "number");
        readiness = scored.length
          ? Math.round(scored.reduce((sum, question) => sum + (question.score ?? 0), 0) / scored.length)
          : result.score;

        await prisma.interviewSession.update({
          where: { id: session.id },
          data: { questions: nextQuestions, readiness }
        });
      }
    }

    return NextResponse.json({ ...result, readiness });
  } catch (error) {
    if (error instanceof z.ZodError) {
      return NextResponse.json({ message: "A complete answer is required for scoring." }, { status: 400 });
    }

    const message = error instanceof Error ? error.message : "Answer scoring failed.";
    if (message.includes("JSON")) {
      return NextResponse.json({ message: "AI returned invalid JSON after retry." }, { status: 500 });
    }

    return NextResponse.json(
      { message: "Claude failed while scoring the answer. Please retry in a moment." },
      { status: 502 }
    );
  }
}
