import { NextResponse } from "next/server";
import { z } from "zod";
import { createFallbackInterviewPrep, generateInterviewPrep } from "@/lib/ai/interview-gen";
import { getRequestUser } from "@/lib/auth";
import { hasAnthropicConfig, hasDatabaseConfig } from "@/lib/env";
import { prisma } from "@/lib/prisma";
import type { Seniority } from "@/types/interview";

export const runtime = "nodejs";

const generateSchema = z.object({
  jobTitle: z.string().min(2),
  jobDescription: z.string().min(20),
  seniority: z.enum(["junior", "mid", "senior", "lead"]),
  sessionId: z.string().optional()
});

export async function POST(request: Request) {
  const user = await getRequestUser();
  if (!user) {
    return NextResponse.json({ message: "Authentication required." }, { status: 401 });
  }

  try {
    const input = generateSchema.parse(await request.json());
    const seniority: Seniority = input.seniority;
    const result = hasAnthropicConfig()
      ? await generateInterviewPrep(input.jobTitle, seniority, input.jobDescription)
      : createFallbackInterviewPrep(input.jobTitle, seniority);

    let sessionId = input.sessionId ?? null;
    if (hasDatabaseConfig() && user.dbUserId) {
      const saved = await prisma.interviewSession.create({
        data: {
          userId: user.dbUserId,
          jobTitle: input.jobTitle,
          jobDesc: input.jobDescription,
          topics: result.topics,
          questions: result.questions,
          readiness: 0
        }
      });
      sessionId = saved.id;
    }

    return NextResponse.json({ ...result, sessionId });
  } catch (error) {
    if (error instanceof z.ZodError) {
      return NextResponse.json({ message: "Job title, description, and seniority are required." }, { status: 400 });
    }

    const message = error instanceof Error ? error.message : "Interview generation failed.";
    if (message.includes("JSON")) {
      return NextResponse.json({ message: "AI returned invalid JSON after retry." }, { status: 500 });
    }

    if (message.includes("Prisma")) {
      return NextResponse.json({ message: "Database write failed; no partial session was saved." }, { status: 500 });
    }

    return NextResponse.json(
      { message: "Claude failed while generating prep material. Please retry in a moment." },
      { status: 502 }
    );
  }
}
