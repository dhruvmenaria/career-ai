import { NextResponse } from "next/server";
import { z } from "zod";
import { analyseJDWithAI, createFallbackResumeResult, parseResumeWithAI, tailorResumeWithAI } from "@/lib/ai/resume-tailor";
import { getRequestUser } from "@/lib/auth";
import { hasAnthropicConfig, hasDatabaseConfig } from "@/lib/env";
import { prisma } from "@/lib/prisma";

export const runtime = "nodejs";

const tailorSchema = z.object({
  resumeText: z.string().min(20),
  jobDescription: z.string().min(20),
  sessionId: z.string().optional()
});

export async function POST(request: Request) {
  const user = await getRequestUser();
  if (!user) {
    return NextResponse.json({ message: "Authentication required." }, { status: 401 });
  }

  try {
    const body: unknown = await request.json();
    const input = tailorSchema.parse(body);
    const result = hasAnthropicConfig()
      ? await tailorResumeWithAI(await parseResumeWithAI(input.resumeText), await analyseJDWithAI(input.jobDescription))
      : createFallbackResumeResult(input.resumeText, input.jobDescription);

    let sessionId = input.sessionId ?? null;
    if (hasDatabaseConfig() && user.dbUserId) {
      const saved = await prisma.resumeSession.upsert({
        where: { id: input.sessionId ?? "missing-session-id" },
        update: {
          originalResume: input.resumeText,
          tailoredResume: JSON.stringify(result.tailoredResume),
          atsScoreBefore: result.atsScoreBefore,
          atsScoreAfter: result.atsScoreAfter,
          keywordMatches: result.keywordMatches
        },
        create: {
          userId: user.dbUserId,
          title: result.tailoredResume.name || "Tailored resume",
          originalResume: input.resumeText,
          tailoredResume: JSON.stringify(result.tailoredResume),
          atsScoreBefore: result.atsScoreBefore,
          atsScoreAfter: result.atsScoreAfter,
          keywordMatches: result.keywordMatches
        }
      });
      sessionId = saved.id;
    }

    const payload = JSON.stringify({ ...result, sessionId });
    const stream = new ReadableStream({
      start(controller) {
        controller.enqueue(new TextEncoder().encode(payload));
        controller.close();
      }
    });

    return new Response(stream, {
      headers: {
        "content-type": "application/json"
      }
    });
  } catch (error) {
    if (error instanceof z.ZodError) {
      return NextResponse.json({ message: "Resume text and job description are required." }, { status: 400 });
    }

    const message = error instanceof Error ? error.message : "Unable to tailor resume.";
    if (message.includes("JSON")) {
      return NextResponse.json({ message: "AI returned invalid JSON after retry." }, { status: 500 });
    }

    if (message.includes("Prisma")) {
      return NextResponse.json({ message: "Database write failed; no partial session was saved." }, { status: 500 });
    }

    return NextResponse.json(
      { message: "Claude failed while tailoring your resume. Please retry in a moment." },
      { status: 502 }
    );
  }
}
