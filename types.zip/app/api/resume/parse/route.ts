import { NextResponse } from "next/server";
import { z } from "zod";
import { hasAnthropicConfig } from "@/lib/env";
import { parseResumeWithAI } from "@/lib/ai/resume-tailor";
import { parseDOCX } from "@/lib/parsers/docx-parser";
import { parsePDF } from "@/lib/parsers/pdf-parser";
import { getRequestUser } from "@/lib/auth";

export const runtime = "nodejs";

const MAX_FILE_SIZE = 5 * 1024 * 1024;

const rawTextSchema = z.object({
  text: z.string().min(20, "Paste at least 20 characters of resume text.")
});

async function extractTextFromFile(file: File) {
  if (file.size > MAX_FILE_SIZE) {
    return { error: NextResponse.json({ message: "Resume file is larger than 5MB." }, { status: 413 }) };
  }

  const buffer = Buffer.from(await file.arrayBuffer());
  const name = file.name.toLowerCase();
  const type = file.type;

  if (type === "application/pdf" || name.endsWith(".pdf")) {
    return { rawText: await parsePDF(buffer) };
  }

  if (
    type === "application/vnd.openxmlformats-officedocument.wordprocessingml.document" ||
    name.endsWith(".docx")
  ) {
    return { rawText: await parseDOCX(buffer) };
  }

  if (type === "text/plain" || name.endsWith(".txt")) {
    return { rawText: buffer.toString("utf8") };
  }

  return { error: NextResponse.json({ message: "Unsupported file format. Upload PDF, DOCX, or TXT." }, { status: 415 }) };
}

export async function POST(request: Request) {
  const user = await getRequestUser();
  if (!user) {
    return NextResponse.json({ message: "Authentication required." }, { status: 401 });
  }

  try {
    const contentType = request.headers.get("content-type") ?? "";
    let rawText = "";

    if (contentType.includes("multipart/form-data")) {
      const formData = await request.formData();
      const file = formData.get("file");
      const text = formData.get("text");

      if (file instanceof File && file.size > 0) {
        const extracted = await extractTextFromFile(file);
        if (extracted.error) return extracted.error;
        rawText = extracted.rawText ?? "";
      } else if (typeof text === "string") {
        rawText = rawTextSchema.parse({ text }).text;
      }
    } else {
      const body: unknown = await request.json();
      rawText = rawTextSchema.parse(body).text;
    }

    if (!rawText.trim()) {
      return NextResponse.json({ message: "No resume text found." }, { status: 400 });
    }

    if (!hasAnthropicConfig()) {
      return NextResponse.json({
        parsedResume: {
          name: "Candidate",
          email: "",
          phone: "",
          location: "",
          summary: rawText.split(/\r?\n/).find(Boolean) ?? "",
          experience: [],
          education: [],
          skills: [],
          certifications: []
        },
        rawText,
        warning: "ANTHROPIC_API_KEY is not configured, so parsing is using a safe preview shape."
      });
    }

    const parsedResume = await parseResumeWithAI(rawText);
    return NextResponse.json({ parsedResume, rawText });
  } catch (error) {
    if (error instanceof z.ZodError) {
      return NextResponse.json({ message: error.issues[0]?.message ?? "Invalid request." }, { status: 400 });
    }

    const message = error instanceof Error ? error.message : "Unable to parse resume.";
    if (message.includes("JSON")) {
      return NextResponse.json({ message: "AI returned invalid JSON after retry." }, { status: 500 });
    }

    return NextResponse.json(
      { message: "Resume parsing failed. Please retry or upload a cleaner file." },
      { status: 502 }
    );
  }
}
