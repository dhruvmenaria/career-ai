import { NextResponse } from "next/server";
import Stripe from "stripe";

export const runtime = "nodejs";

export async function POST(request: Request) {
  const secret = process.env.STRIPE_WEBHOOK_SECRET;
  const stripeKey = process.env.STRIPE_SECRET_KEY;

  if (!secret || !stripeKey) {
    return NextResponse.json({ message: "Stripe webhook is scaffolded but not configured." }, { status: 200 });
  }

  const stripe = new Stripe(stripeKey);
  const signature = request.headers.get("stripe-signature");

  if (!signature) {
    return NextResponse.json({ message: "Missing Stripe signature." }, { status: 400 });
  }

  try {
    stripe.webhooks.constructEvent(await request.text(), signature, secret);
    return NextResponse.json({ received: true });
  } catch {
    return NextResponse.json({ message: "Invalid Stripe webhook signature." }, { status: 400 });
  }
}
