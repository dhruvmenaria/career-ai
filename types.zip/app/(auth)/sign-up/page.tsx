import { SignUp } from "@clerk/nextjs";
import Link from "next/link";
import { ArrowRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { hasClerkConfig } from "@/lib/env";
import type { Metadata } from "next";

export const metadata: Metadata = { title: "Sign Up" };

export default function SignUpPage() {
  const hasClerk = hasClerkConfig();

  return (
    <div className="flex min-h-screen items-center justify-center gradient-hero bg-background px-4">
      <div className="w-full max-w-md animate-in-up">
        <div className="mb-8 text-center">
          <div className="mx-auto mb-4 flex h-12 w-12 items-center justify-center rounded-2xl gradient-primary text-white text-xl font-bold shadow-lg">
            AI
          </div>
          <h1 className="text-2xl font-bold tracking-tight">Create your CareerAI account</h1>
          <p className="mt-1 text-sm text-muted-foreground">Start tailoring resumes and acing interviews</p>
        </div>
        
        {hasClerk ? (
          <SignUp />
        ) : (
          <div className="rounded-xl border border-border/50 bg-card p-6 shadow-sm text-center">
            <h3 className="mb-2 font-semibold">Demo Mode Active</h3>
            <p className="mb-6 text-sm text-muted-foreground">
              Clerk API keys are missing. You can bypass login in demo mode.
            </p>
            <Button asChild className="w-full">
              <Link href="/dashboard">
                Continue to Dashboard <ArrowRight className="ml-2 h-4 w-4" />
              </Link>
            </Button>
          </div>
        )}
      </div>
    </div>
  );
}
