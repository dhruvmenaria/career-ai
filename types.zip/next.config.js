/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true,
  experimental: {
    serverActions: {
      bodySizeLimit: "5mb"
    }
  },
  eslint: {
    ignoreDuringBuilds: true,
    dirs: ["app", "components", "lib", "types"]
  },
  typescript: {
    ignoreBuildErrors: true
  },
  webpack: (config, { isServer }) => {
    if (isServer) {
      // pdf-parse uses 'canvas' which is optional — ignore it
      config.resolve.alias.canvas = false;
    }
    return config;
  }
};

module.exports = nextConfig;
