"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import {
  BriefcaseBusiness,
  FileText,
  LayoutDashboard,
  MessagesSquare,
  Moon,
  Sun,
  ChevronRight,
  Sparkles,
} from "lucide-react";
import { useTheme } from "next-themes";
import { cn } from "@/lib/utils";

const navItems = [
  { href: "/dashboard", label: "Dashboard", icon: LayoutDashboard, exact: true },
  { href: "/resume", label: "Resume", icon: FileText, exact: false },
  { href: "/interview", label: "Interview Prep", icon: MessagesSquare, exact: false },
  { href: "/jobs", label: "Job Tracker", icon: BriefcaseBusiness, exact: false },
];

export function Sidebar() {
  const pathname = usePathname();
  const { theme, setTheme } = useTheme();

  return (
    <aside className="flex h-full w-full flex-col border-r border-border/50 bg-card px-3 py-5">
      {/* Logo */}
      <Link href="/" className="mb-8 flex items-center gap-3 px-2">
        <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl gradient-primary shadow-md">
          <Sparkles className="h-4 w-4 text-white" />
        </div>
        <div>
          <span className="block text-sm font-bold tracking-tight">CareerAI</span>
          <span className="block text-[10px] text-muted-foreground">AI-powered careers</span>
        </div>
      </Link>

      {/* Nav */}
      <nav className="flex flex-1 flex-col gap-1">
        <p className="mb-2 px-3 text-[10px] font-semibold uppercase tracking-widest text-muted-foreground/60">
          Navigation
        </p>
        {navItems.map((item) => {
          const Icon = item.icon;
          const active = item.exact ? pathname === item.href : pathname.startsWith(item.href);
          return (
            <Link
              key={item.href}
              href={item.href}
              className={cn("sidebar-link group", active && "sidebar-link-active")}
            >
              <Icon className="h-4 w-4 shrink-0" />
              <span className="flex-1">{item.label}</span>
              {active && <ChevronRight className="h-3.5 w-3.5 opacity-60" />}
            </Link>
          );
        })}
      </nav>

      {/* Quick actions */}
      <div className="mt-4 space-y-2">
        <Link
          href="/resume/new"
          className="flex w-full items-center gap-2 rounded-lg px-3 py-2 text-xs font-medium text-primary hover:bg-accent transition-colors"
        >
          <FileText className="h-3.5 w-3.5" />
          Tailor New Resume
        </Link>
        <Link
          href="/interview/new"
          className="flex w-full items-center gap-2 rounded-lg px-3 py-2 text-xs font-medium text-primary hover:bg-accent transition-colors"
        >
          <MessagesSquare className="h-3.5 w-3.5" />
          New Interview Prep
        </Link>
      </div>

      {/* Theme toggle */}
      <div className="mt-4 border-t border-border/50 pt-4">
        <button
          onClick={() => setTheme(theme === "dark" ? "light" : "dark")}
          className="flex w-full items-center gap-3 rounded-lg px-3 py-2 text-sm text-muted-foreground transition-colors hover:bg-accent hover:text-accent-foreground"
        >
          {theme === "dark" ? <Sun className="h-4 w-4" /> : <Moon className="h-4 w-4" />}
          {theme === "dark" ? "Light mode" : "Dark mode"}
        </button>
      </div>
    </aside>
  );
}
